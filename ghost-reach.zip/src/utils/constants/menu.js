export const MENU = {
  howworks: "/#howwork",

  features: "/#features",

  pricing: "/#price",

  blog: "/blog",

  faq: "/#faq",
};
