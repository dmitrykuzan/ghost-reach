export const title = {
  en: {
    hello: "Hello",
  },
};
