export const navigation = {
  en: {
    howworks: "How It Works",
    features: "Features",
    pricing: "Pricing",
    blog: "Blog",
    faq: "FAQ",
  },
};
