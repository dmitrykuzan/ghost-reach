import { BlogContent } from "./sections/blog-content";

export const Blog = () => {
  return (
    <>
      <BlogContent />
    </>
  );
};
