export * from "./home";
export * from "./blog";
export * from "./policy";
export * from "./terms";
