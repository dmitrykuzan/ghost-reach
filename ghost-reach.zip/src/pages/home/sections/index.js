export * from "./hero";
export * from "./how-work";
export * from "./features";
export * from "./price";
export * from "./newsletter";
export * from "./banner";
export * from "./info";
export * from "./testimonials";
